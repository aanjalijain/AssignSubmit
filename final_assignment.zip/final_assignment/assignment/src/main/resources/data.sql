INSERT INTO 
	TBL_UserDetail (userName, userPassword, userStatus) 
VALUES
  	('Lokesh', 'User@1234', 'Active');