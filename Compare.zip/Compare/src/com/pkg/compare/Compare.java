package com.pkg.compare;
import java.io.File;
import java.io.IOException;

public class Compare {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//Runtime.getRuntime().exec(new String[] {"cmd", "/K", "Start"}); 
		File file1 = new File("C:\\Users\\anjajain\\Documents\\jarPoc1.jar");
		File file2 = new File("C:\\Users\\anjajain\\Documents\\jarPoc2.jar");
		/*if (args != null && args.length > 0) {
			file1 = new File(args[0]);
			if (args.length > 1) {
				file2 = new File(args[1]);
			}
		}*/
		// Construct main window and initialise
		CompareFile window = new CompareFile();
		// Pass two files to start with, or instruct to prompt
		window.startCompare(file1, file2, false);

	}

}
