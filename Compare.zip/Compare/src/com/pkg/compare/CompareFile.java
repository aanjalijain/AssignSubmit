package com.pkg.compare;

import java.awt.BorderLayout;
import java.io.File;

public class CompareFile {
	
	/** Two files to compare */
	private File[] _files = new File[2];
	/** Flag to process md5 sums */
	private boolean _checkMd5 = false;

	
	public void startCompare(File inFile1, File inFile2, boolean inMd5)
	{


		File file1 = inFile1;
		File file2 = inFile2;
		if (file1==null || !file1.exists() || !file1.canRead()) {
			System.out.println("Select first file");
			//file1 = selectFile("Select first file", null);
		}
		// Bail if cancel pressed
		if (file1 == null) {return;}
		// Select second file if necessary
		if (file2 == null || !file2.exists() || !file2.canRead()) {
			System.out.println("Select second file");
			//file2 = selectFile("Select second file", file1);
		}
		// Bail if cancel pressed
		if (file2 == null) {return;}
		_files[0] = file1;
		_files[1] = file2;
		new Thread(new Runnable() {
			public void run() {
				doCompare();
			}
		}).start();

		
	}
	private void doCompare()
	{
		CompareResults results = Comparer.compare(_files[0], _files[1], _checkMd5);
		System.out.println(results.getEntryList());
		final boolean archivesDifferent = (results.getStatus() == EntryDetails.EntryStatus.CHANGED_SIZE);
		if (archivesDifferent) {
			System.out.println("Archives have different size (" + results.getSize(0) + ", " + results.getSize(1) + ")");
		}
		else {
			System.out.println("Archives have the same size (" + results.getSize(0)+ ")");
		}
		/*_detailsDisplays = new JarDetailsDisplay[2];
		_detailsDisplays[0] = new JarDetailsDisplay();
		System.out.println(_detailsDisplays[0]);
		_detailsDisplays[1] = new JarDetailsDisplay();
		System.out.println(_detailsDisplays[1]);
		_detailsDisplays[0].setContents(_files[0], results, 0);
		_detailsDisplays[1].setContents(_files[1], results, 1);*/
		// System.out.println(_files[0].getName() + " has " + results.getNumFiles(0) + " files, "
		//	+ _files[1].getName() + " has " + results.getNumFiles(1));
		if (results.getEntriesDifferent()) {
			System.out.println((archivesDifferent?"and":"but") + " the files have different contents");
		}
		else {
			if (results.getEntriesMd5Checked()) {
				System.out.println((archivesDifferent?"but":"and") + " the files have exactly the same contents");
			}
			else {
				System.out.println((archivesDifferent?"but":"and") + " the files appear to have the same contents");
			}
		}
/*		_md5Button.setEnabled(!results.getEntriesMd5Checked());
		_checkMd5 = false;
		_refreshButton.setEnabled(true);*/
		// Possibilities:
		//      Jars have same size, same md5 sum, same contents
		//      Jars have same size but different md5 sum, different contents
		//      Jars have different size, different md5 sum, but same contents
		//      Individual files have same size but different md5 sum
		//      Jars have absolutely nothing in common

		// Maybe poll each minute to check if last modified has changed, then prompt to refresh?
	}

}
